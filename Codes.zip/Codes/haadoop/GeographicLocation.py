# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

from mrjob.job import MRJob

class GeographicalLocaltion(MRJob):
    
    def mapper(self,_,line):
        fields=line.split(';')
        yield fields[20],1
        
    def reducer(self,key,vals):
        sums=sum(vals)
        yield key, sums
        
if __name__=="__main__":
    GeographicalLocaltion.run()
    
