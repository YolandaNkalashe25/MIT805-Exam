#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Nov  2 21:12:11 2020

@author: yolandankalashe
"""

from mrjob.job import MRJob

class Loan(MRJob):
    
    def mapper(self,_,line):
        Quarter=""
        fields=line.split(',')
        
        default=fields[13]
        date=fields[12]
        date_list=date.split('/')
        Year=date_list[0]
        
        if len(date_list)==3:
           month=int(date_list[1])
           if  month<4: 
               Quarter="Q1"
               
        if default== "Default": 
            yield (Year+"/"+Quarter),1
        
    def reducer(self,key,vals):
        sums=sum(vals)
        yield key, sums
        
if __name__=="__main__":
    Loan.run()
