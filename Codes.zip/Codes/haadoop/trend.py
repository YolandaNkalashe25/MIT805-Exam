#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Nov 26 15:55:46 2020

@author: yolandankalashe
"""

from mrjob.job import MRJob

class Trend(MRJob):
    
    def mapper(self,_,line):

        fields=line.split(',')
    
        date=fields[12]
        date_list=date.split('/')
        Year=date_list[0]
               
        if Year == "2019" or "2020": 
            yield (Year),1
        
    def reducer(self,key,vals):
        sums=sum(vals)
        yield key, sums
        
if __name__=="__main__":
    Trend.run()
