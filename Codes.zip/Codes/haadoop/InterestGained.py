#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Nov 26 06:42:08 2020

@author: yolandankalashe
"""

from mrjob.job import MRJob


class InterestGained(MRJob):
   
    def mapper(self, _, line):
        fields = line.strip(" ") 
        Loan_amount=(fields[1])
        
        Loan_term=fields[4]
        term_val=Loan_term.split()
        term=term_val[0]
        
        monthly_payment=fields[6]
        
        total_payment=0
        Interest_received=0
        date= fields[12]
        date_list=date.split('/')
        year=date_list[0]
        
        if Loan_amount != ';':
            Loan_amount=int(float(fields[1]))
            
        if term != ';':    
            term=int(term)
        
        if len(monthly_payment)>1 :
        
            monthly_payment=int(fields[6])
            
            total_payment= int(term*monthly_payment)
        
            Interest_received=int(total_payment-Loan_amount)

    
        yield (year,Interest_received) 
        


    def reducer(self, key, values):
        tot_interest=sum(values)

        yield (key,values) 
 

if __name__ == '__main__':
    InterestGained.run()
