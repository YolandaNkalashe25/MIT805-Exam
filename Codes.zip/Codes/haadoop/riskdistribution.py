#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Nov 26 06:19:35 2020

@author: yolandankalashe
"""

from mrjob.job import MRJob

class RiskDistribution(MRJob):
    
    def mapper(self,_,line):
        fields=line.split(';')
        
        
        yield fields[7],1
        
    def reducer(self,key,vals):
        sums=sum(vals)
        yield key, sums
        
if __name__=="__main__":
    RiskDistribution.run()
    
